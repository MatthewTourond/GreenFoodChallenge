package com.android.greenfoodchallenge.carboncalculator;

public class RegisterUser {
    private String email;
    private String password;

    public RegisterUser(){

    }
}
