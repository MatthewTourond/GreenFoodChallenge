
![Add Meal](READMEPictures/addMeals.png)

![Add Pledge](READMEPictures/addPledge.png)

![Authentication](READMEPictures/authenticationPage.png)

![Carbon Calculator](READMEPictures/carbonCalc.png)

![Calorie Calculator](READMEPictures/calorieCalc.png)

![About](READMEPictures/CO2about.png)

![Delete Meal](READMEPictures/deleteMeal.png)

![Menu](READMEPictures/menu.png)

![Profile](READMEPictures/profile.png)

![Registration](READMEPictures/registration.png)

![Results](READMEPictures/results.png)

![Savings Calculator](READMEPictures/savingsCalc.png)

![Splash Screen](READMEPictures/splash.png)

![View Meals](READMEPictures/viewMeals.png)

![View Pledges](READMEPictures/viewPledges.png)

Icons made by Freepik from www.flaticon.com